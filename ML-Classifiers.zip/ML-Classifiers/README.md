# ML-Classifiers

Running machine learning classifiers for face detection and digit recognition

## Libraries to install

```ssh
pip install numpy
pip install sklearn
```
