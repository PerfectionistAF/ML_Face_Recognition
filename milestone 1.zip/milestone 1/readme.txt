In the provided python files, the following has been changed:
samples.py		where: #Testing
			ammended: producedata
			
Libraries that need to be installed

	sklearn
	matplotlib

then you simply download the code and run each file (naive bayes.py , knn.py )


